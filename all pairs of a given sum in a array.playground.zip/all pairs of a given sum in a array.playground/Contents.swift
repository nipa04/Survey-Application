//: Playground - noun: a place where people can play

import UIKit

var array = [1,2,3,4,5]
let k = 6

for index in 0..<array.count {
    for innerIndex in (index + 1)..<array.count {
        let p = array[index] + array[innerIndex]
        if p == k {
            print("\(array[index]) and \(array[innerIndex])")
        }
    }
}
