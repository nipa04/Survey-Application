//: Playground - noun: a place where people can play

import UIKit

var str = "hello"
var character = Array(str)
character.count
for index in 0..<character.count/2 {
    let leftIndex = index
    let rightIndex = ((character.count) - leftIndex) - 1
    let temp = character[leftIndex]
    character[leftIndex] = character[rightIndex]
    character[rightIndex] = temp
}
print(character)

