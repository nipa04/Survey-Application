//: Playground - noun: a place where people can play

import UIKit

var array = [1,2,3,4,5,6,7,9]
var sum = 0
for index in 0..<array.count {
    sum += array[index]
}
print(sum)

let n = 9
let Sn = (n * (n+1))/2
print (Sn)

var p = Sn - sum
if p != 0 {
    print("missing number is \(p)")
}
else {
    print("No missing number ")
}
