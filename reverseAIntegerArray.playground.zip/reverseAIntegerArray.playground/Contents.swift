//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello playground"
//var char = Array(str)
//char.count
//for index in 0..<char.count/2 {
//    let leftIndex = index
//    let rightIndex = (char.count - leftIndex) - 1
//    print("\(char[leftIndex]) and \(char[rightIndex])")
//    var temp = char[leftIndex]
//    char[leftIndex] = char[rightIndex]
//    char[rightIndex] = temp
//}
//print(char)


var array = [1,2,3,4,5,6,7,8,9,10]
for index in 0..<array.count/2 {
    let leftIndex = index
    let rightIndex = (array.count - leftIndex) - 1
    let temp = array[rightIndex]
    array[rightIndex] = array[leftIndex]
    array[leftIndex] = temp
}
print(array)

