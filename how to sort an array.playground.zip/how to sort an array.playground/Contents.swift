//: Playground - noun: a place where people can play

import UIKit

var array = [4,3,2,0,5,1]

// Sorting array
// ascending, array = [0,1,2,3,4,5]
// decending, array = [5,4,3,2,1,0]
// this is for ascending order

for counter in 0..<array.count {
    for index in 0..<array.count - counter - 1 {
        if array[index] > array[index + 1]{
            let k = array[index]
            array[index] = array[index + 1]
            array[index + 1] = k
        }
    }
}

print(array)
