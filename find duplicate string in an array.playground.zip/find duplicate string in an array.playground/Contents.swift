//: Playground - noun: a place where people can play

import UIKit

func contains (_ array : [Character],_ k : Character ) -> Bool {
    for index in 0..<array.count{
        if k == array[index] {
            return true
        }
    }
    return false
}


var str = "Hello playground"
var char = Array(str)
print(char)
var char2 = [Character]()

for index in 0..<char.count {
    if contains(char2, char[index]) == false {
        char2.append(char[index])
    }
}
print(char2)


//for index in 0..<char.count {
//    if char2.contains(char[index]) == false {
//        char2.append(char[index])
//    }
//}

