
//: Playground - noun: a place where people can play

import UIKit

var array = [1,2,-3,6,7,4,10,5,8,9] 

var minValue = Int.max
var maxValue = Int.min

for index in 0..<array.count{
    if array[index] < minValue {
        minValue = array[index]
    }
    if array[index] > maxValue {
        maxValue = array[index]
    }
}

print(minValue)
print(maxValue)

