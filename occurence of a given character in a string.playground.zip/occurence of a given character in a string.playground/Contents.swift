//: Playground - noun: a place where people can play

import UIKit


var str = "hello"
var char = Array(str)
let k:Character = "l"
var char2 = [Character]()

for index in 0..<char.count {
    if k == char[index] {
        char2.append(k)
    }
}

print(char2)
print(char2.count)
