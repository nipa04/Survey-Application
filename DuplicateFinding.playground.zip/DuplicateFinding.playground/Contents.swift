//: Playground - noun: a place where people can play

import UIKit

func contains(_ array : [Int] , k : Int) -> Bool {
    for index in 0..<array.count {
        if k == array[index] {
            return true
        }
    }
    return false
}


var array = [1,2,3,3,4,5,4,2]
var array2 = [Int]()
for index in 0..<array.count {
    if contains(array2, k: array[index]) == false {
        array2.append(array[index])
        
    }
   
}
print(array2)



//for index in 0..<array.count {
//    if  array2.contains(array[index]) == false {
//        array2.append(array[index])
//    }
//}
//print(array2)

