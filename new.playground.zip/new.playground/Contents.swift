//: Playground - noun: a place where people can play

import UIKit

var str = "hello"
var char = Array(str)
var char2 = [Character]()

for index in 0..<char.count {
    if char2.contains(char[index]) == false{
        char2.append(char[index])
    }
}

print(char2)
