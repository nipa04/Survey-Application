//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var array = [1,-2,4,678,5,-98,5,77,89,4455]

var maxValue = Int.min
//print(maxValue)

for index in 0..<array.count {
    if array[index] > maxValue {
        maxValue = array[index]
    }
}

print(maxValue)
